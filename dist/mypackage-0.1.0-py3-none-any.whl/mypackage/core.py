def calMon6m(df):
    df = df.sort_values(["permno", "time_avail_m"], ascending=[True, True])
    mon6m = df["ret2"]
    #mon6m = df_mon6m.groupby('time_avail_m').mean()
    Mom6m = ((1 + mon6m.shift(1)) * (1 + mon6m.shift(2)) * (1 + mon6m.shift(3)) * \
                (1 + mon6m.shift(4)) * (1 + mon6m.shift(5))) - 1
    return Mom6m


# 1 52-week high
# gen temp = max(l1.maxpr, l2.maxpr, l3.maxpr, l4.maxpr, l5.maxpr, l6.maxpr, ///
# 	l7.maxpr, l8.maxpr, l9.maxpr, l10.maxpr, l11.maxpr, l12.maxpr)
# gen High52 = (abs(prc)/cfacshr)/temp	
# drop temp*
# label var High52 "52-week High"
def High52(df):
    df_high52 = df[["time_avail_m", "maxpr", "prc", "cfacshr"]].groupby('time_avail_m').mean()
    for i in range(1,13):
        df_high52["maxpr_lag{}".format(i)] = df_high52["maxpr"].shift(i)
    df_high52["maxpr"] = df_high52[["maxpr_lag1","maxpr_lag2","maxpr_lag3","maxpr_lag4",\
                                   "maxpr_lag5","maxpr_lag6","maxpr_lag7","maxpr_lag8",\
                                   "maxpr_lag9","maxpr_lag10","maxpr_lag11","maxpr_lag12"]].max(axis=1)
    High52 = ((abs(df_high52["prc"]) / df_high52["cfacshr"]) / df_high52["maxpr"]).fillna(0)
    return High52


# 2 Accruals
# gen tempTXP = txp
# replace tempTXP = 0 if mi(txp)

# gen Accruals = ( (act - l12.act) - (che - l12.che) - ( (lct - l12.lct) - ///
# 	(dlc - l12.dlc) - (tempTXP - l12.tempTXP) )) / ( (at + l12.at)/2)
# label var Accruals "Accruals"
# drop temp*
def Accruals(df_copy1):
    df_copy1["temTXP"] = df_copy1["txp"].fillna(0)
    df_new = df_copy1[["time_avail_m", "act", "che", "lct", "dlc", "temTXP", "at"]].groupby('time_avail_m').mean()
    Accruals = ( (df_new["act"] - df_new["act"].shift(12)) - (df_new["che"] - df_new["che"].shift(12)) - \
                ( (df_new["lct"] - df_new["lct"].shift(12)) - (df_new["dlc"] - df_new["dlc"].shift(12)) - \
                 (df_new["temTXP"] - df_new["temTXP"].shift(12)) )) / ((df_new["at"] + df_new["at"].shift(12))/2)
    return Accruals


# 4 Illiquidity
# gen Illiquidity = (ill + l.ill + l2.ill + l3.ill + l4.ill + l5.ill + ///
# 	l6.ill + l7.ill + l8.ill + l9.ill + l10.ill + l11.ill)/12
# label var Illiquidity "Illiquidity"
def Illiquidity(df_copy1):
    df_new = df_copy1[["time_avail_m", "ill"]].groupby('time_avail_m').mean()
    for i in range(1,12):
        df_new["ill_lag{}".format(i)] = df_new["ill"].shift(i)
    Illiquidity = (df_new["ill"] + df_new["ill_lag1"] + df_new["ill_lag2"] + \
                             df_new["ill_lag3"] + df_new["ill_lag4"] + df_new["ill_lag5"] + \
                             df_new["ill_lag6"] + df_new["ill_lag7"] + df_new["ill_lag8"] + \
                             df_new["ill_lag9"] + df_new["ill_lag10"] + df_new["ill_lag11"]) /12
    return df_new["ill_lag1"]


# 6 Asset Growth
# gen AssetGrowth = (at - l12.at)/l12.at 
# label var AssetGrowth "Asset Growth"
def AssetGrowth(df_copy1):
    df_new = df_copy1[["time_avail_m", "at"]].groupby('time_avail_m').mean()
    AssetGrowth = (df_new["at"] - df_new["at"].shift(12)) / df_new["at"].shift(12)
    return AssetGrowth


# 7 Asset Turnover
# gen temp = (rect + invt + aco + ppent + intan - ap - lco - lo) 
# gen AssetTurnover = sale/((temp + l12.temp)/2)
# drop temp
# replace AssetTurnover = . if AssetTurnover < 0
# label var AssetTurnover "Asset Turnover"
def AssetTurnover(df_copy1):
    df_copy1["temp"] = df_copy1["rect"] + df_copy1["invt"] + df_copy1["aco"] + df_copy1["ppent"] + \
                        df_copy1["intan"] - df_copy1["ap"] - df_copy1["lco"] - df_copy1["lo"]
    df_new = df_copy1[["time_avail_m", "temp", "sale"]].groupby('time_avail_m').mean()
    df_new["AssetTurnover"] = df_new["sale"] / ((df_new["temp"] + df_new["temp"].shift(12)) / 2)
    df_new.loc[df_new["AssetTurnover"]<0, "AssetTurnover"] = 0
    AssetTurnover = df_new["AssetTurnover"]
    return AssetTurnover


# 13 Change in Asset Turnover
# gen ChAssetTurnover = AssetTurnover - l12.AssetTurnover
# label var ChAssetTurnover "Change in Asset Turnover"
def ChAssetTurnover(df_copy1):
    df_copy1["temp"] = df_copy1["rect"] + df_copy1["invt"] + df_copy1["aco"] + df_copy1["ppent"] + \
                        df_copy1["intan"] - df_copy1["ap"] - df_copy1["lco"] - df_copy1["lo"]
    df_new = df_copy1[["time_avail_m", "temp", "sale"]].groupby('time_avail_m').mean()
    df_new["AssetTurnover"] = df_new["sale"] / ((df_new["temp"] + df_new["temp"].shift(12)) / 2)
    df_new.loc[df_new["AssetTurnover"]<0, "AssetTurnover"] = 0
    #df_new = df_copy1[["time_avail_m", "AssetTurnover"]].groupby('time_avail_m').mean()
    ChAssetTurnover = df_new["AssetTurnover"] - df_new["AssetTurnover"].shift(12)
    return ChAssetTurnover


# 413 Change in Forecast and Accrual
# gen tempAccruals = ( (act - l12.act) - (che - l12.che) - ( (lct - l12.lct) - ///
# 	(dlc - l12.dlc) - (txp - l12.txp) )) / ( (at + l12.at)/2)
# egen tempsort = fastxtile(tempAccruals), by(time_avail_m) n(2)
# gen ChForecastAccrual = 1 if meanest > l.meanest & !mi(meanest) & !mi(l.meanest)
# replace ChForecastAccrual = 0 if meanest < l.meanest & !mi(meanest) & !mi(l.meanest)
# replace ChForecastAccrual = . if tempsort == 1
# drop temp*
# label var ChForecastAccrual "Change in Forecast and Accrual"
def ChForecastAccrual(df_copy1):
    # df_copy1["temTXP"] = df_copy1["txp"].fillna(0)
    df_new = df_copy1[["time_avail_m", "act", "che", "lct", "dlc", "txp", "at"]].groupby('time_avail_m').mean()
    ChForecastAccrual = ( (df_new["act"] - df_new["act"].shift(12)) - (df_new["che"] - df_new["che"].shift(12)) - \
                ( (df_new["lct"] - df_new["lct"].shift(12)) - (df_new["dlc"] - df_new["dlc"].shift(12)) - \
                 (df_new["txp"] - df_new["txp"].shift(12)) )) / ((df_new["at"] + df_new["at"].shift(12))/2)
    return ChForecastAccrual


# 14 Change in Profit Margin
# gen ChPM = PM - l12.PM
# label var ChPM "Change in Profit Margin"
def ChPM(df_copy1):
    df_new = df_copy1[["time_avail_m", "PM"]].groupby('time_avail_m').mean()
    ChPM = df_new["PM"] - df_new["PM"].shift(12)
    return ChPM

# 22 Dividends
# gen DivInd = ( (l11.ret > l11.retx) )
# *replace DivInd = . if abs(prc) < 5
# label var DivInd "Dividend Indicator"

def DivInd(df_copy1):
    df_new = df_copy1[["time_avail_m", "ret", "retx", "prc"]].groupby('time_avail_m').mean()
    df_new["DivInd"] = df_new["ret"].shift(11) > df_new["retx"].shift(11)
    df_new.loc[abs(df_new["prc"]) < 5, "DivInd"] = 0
    DivInd = df_new["DivInd"]
    return DivInd


# 23 Down Forecast
# gen DownForecast = (meanest < l.meanest)
# label var DownForecast "Down Forecast EPS"
def DownForecast(df_copy1):
    df_new = df_copy1[["time_avail_m", "meanest"]].groupby('time_avail_m').mean()
    df_new["DownForecast"] = df_new["meanest"] < df_new["meanest"].shift(1)
    DownForecast = df_new["DownForecast"]
    return DownForecast


